function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}// Variáveis do jogo
let veiculo;
let fazendas = [];
let casas = [];
let comidaColetada = false;
let destinoAtual;
let tempoRestante = 60; // Em segundos
let pontuacao = 0;

function setup() {
  createCanvas(800, 600);
  // Inicializa o veículo no centro da tela
  veiculo = new Veiculo(width / 2, height / 2);
  // Cria algumas fazendas (pontos de coleta)
  fazendas.push(new Ponto(100, 100, "fazenda"));
  fazendas.push(new Ponto(250, 50, "fazenda"));
  fazendas.push(new Ponto(50, 200, "fazenda"));

  // Cria algumas casas (pontos de entrega)
  casas.push(new Ponto(600, 400, "casa"));
  casas.push(new Ponto(750, 550, "casa"));
  casas.push(new Ponto(500, 300, "casa"));

  // Define o primeiro destino como uma fazenda aleatória
  destinoAtual = random(fazendas);

  setInterval(contarTempo, 1000); // Chama a função contarTempo a cada segundo
}

function draw() {
  background(100, 150, 250); // Cor de fundo para o "céu" ou "estrada"

  // Desenha as zonas (rural e urbana)
  desenhaZonas();

  // Desenha fazendas
  for (let fazenda of fazendas) {
    fazenda.desenha();
  }

  // Desenha casas
  for (let casa of casas) {
    casa.desenha();
  }

  // Desenha o veículo
  veiculo.desenha();
  veiculo.move();
  veiculo.limitaTela();

  // Lógica de colisão e coleta/entrega
  gerenciarInteracoes();

  // Desenha informações do jogo
  desenhaUI();
}

function contarTempo() {
  if (tempoRestante > 0) {
    tempoRestante--;
  } else {
    // Fim do jogo (ou da rodada)
    // Você pode adicionar uma tela de "Game Over" aqui
    console.log("Tempo esgotado! Fim do jogo.");
    noLoop(); // Para o loop draw
  }
}class Veiculo {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.tamanho = 20;
    this.velocidade = 3;
  }

  desenha() {
    fill(255, 0, 0); // Cor vermelha para o veículo
    rectMode(CENTER);
    rect(this.x, this.y, this.tamanho, this.tamanho * 1.5); // Desenha um retângulo como o veículo
  }

  move() {
    // Controle do veículo com as setas do teclado
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.velocidade;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.velocidade;
    }
    if (keyIsDown(UP_ARROW)) {
      this.y -= this.velocidade;
    }
    if (keyIsDown(DOWN_ARROW)) {
      this.y += this.velocidade;
    }
  }

  limitaTela() {
    this.x = constrain(this.x, 0, width);
    this.y = constrain(this.y, 0, height);
  }
}class Ponto {
  constructor(x, y, tipo) {
    this.x = x;
    this.y = y;
    this.tamanho = 30;
    this.tipo = tipo; // "fazenda" ou "casa"
    this.cor = (tipo === "fazenda") ? color(0, 200, 0) : color(0, 0, 200); // Verde para fazenda, azul para casa
  }

  desenha() {
    fill(this.cor);
    rectMode(CENTER);
    rect(this.x, this.y, this.tamanho, this.tamanho);

    // Desenha um texto para identificar
    fill(255);
    textAlign(CENTER, CENTER);
    textSize(10);
    text(this.tipo === "fazenda" ? "Fazenda" : "Casa", this.x, this.y + 15);
  }
}function desenhaZonas() {
  // Zona Rural (parte de cima, por exemplo)
  fill(150, 200, 100); // Verde claro para o campo
  rect(0, 0, width, height / 2);

  // Zona Urbana (parte de baixo)
  fill(180); // Cinza para a cidade
  rect(0, height / 2, width, height / 2);

  // Linha divisória
  stroke(0);
  strokeWeight(2);
  line(0, height / 2, width, height / 2);
  noStroke();
}

function gerenciarInteracoes() {
  // Se ainda não coletou a comida, interage com as fazendas
  if (!comidaColetada) {
    for (let i = 0; i < fazendas.length; i++) {
      let f = fazendas[i];
      if (dist(veiculo.x, veiculo.y, f.x, f.y) < veiculo.tamanho + f.tamanho / 2) {
        // Colisão com a fazenda
        if (f === destinoAtual) {
          comidaColetada = true;
          console.log("Comida coletada da fazenda!");
          // Define um novo destino de entrega (uma casa aleatória)
          destinoAtual = random(casas);
          // Remove a fazenda para evitar coletar de novo, ou marque como "vazia"
          // fazendas.splice(i, 1); // Se quiser que a fazenda "desapareça"
          break; // Sai do loop para evitar múltiplas colisões
        }
      }
    }
  } else {
    // Se já coletou a comida, interage com as casas
    for (let i = 0; i < casas.length; i++) {
      let c = casas[i];
      if (dist(veiculo.x, veiculo.y, c.x, c.y) < veiculo.tamanho + c.tamanho / 2) {
        // Colisão com a casa
        if (c === destinoAtual) {
          comidaColetada = false;
          pontuacao += 100; // Aumenta a pontuação
          tempoRestante = 60; // Reinicia o tempo para a próxima entrega
          console.log("Comida entregue na casa! Pontuação: " + pontuacao);
          // Define o próximo destino como uma fazenda aleatória
          destinoAtual = random(fazendas);
          // Remove a casa, se quiser que ela "desapareça"
          // casas.splice(i, 1);
          if (casas.length === 0) {
            // Se todas as casas foram atendidas, fim do jogo!
            console.log("Parabéns! Todas as entregas concluídas!");
            noLoop();
          }
          break;
        }
      }
    }
  }
}

function desenhaUI() {
  fill(0);
  textSize(16);
  textAlign(LEFT, TOP);
  text("Tempo: " + tempoRestante, 10, 10);
  text("Pontuação: " + pontuacao, 10, 30);
  text(comidaColetada ? "Entregue para a cidade!" : "Colete na fazenda!", 10, 50);

  // Dica para o destino
  if (destinoAtual) {
    fill(255, 165, 0); // Laranja para o destino
    ellipse(destinoAtual.x, destinoAtual.y, 10, 10); // Marca o destino com um círculo
  }
}